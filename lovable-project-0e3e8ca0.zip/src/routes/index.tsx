import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
// Served from /public so the app stays self-contained when deployed to Cloudflare.
const LABEL_BASE_SRC = "/label-base.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "16 Ana Mart Price Label Printer" },
      {
        name: "description",
        content:
          "Create and print rupee price labels for 16 Ana Mart on A4 barcode label sheets in 25x15mm and other standard sizes.",
      },
      { property: "og:title", content: "16 Ana Mart Price Label Printer" },
      {
        property: "og:description",
        content:
          "Enter a price, pick a label size and quantity, then print sharp rupee price labels on A4 sheets.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Size = { id: string; label: string; w: number; h: number; perSheet: number };

// A4 = 210 x 297 mm, printed with 5 mm margins => 200 x 287 mm usable.
const SHEET_W = 200;
const SHEET_H = 287;

const perSheetFor = (w: number, h: number) =>
  Math.max(1, Math.floor(SHEET_W / w) * Math.floor(SHEET_H / h));

const makeSize = (w: number, h: number): Size => ({
  id: `${w}x${h}`,
  label: `${w} × ${h} mm`,
  w,
  h,
  perSheet: perSheetFor(w, h),
});

const SIZES: Size[] = [
  makeSize(25, 15),
  makeSize(38, 21),
  makeSize(50, 25),
  makeSize(65, 38),
  makeSize(100, 50),
];

type Row = { id: number; amount: string; qty: number };

const scaleFor = (text: string) => {
  const digits = text.replace(/[^0-9]/g, "").length;
  return digits <= 2 ? 0.42 : digits === 3 ? 0.33 : digits === 4 ? 0.27 : 0.22;
};

function Index() {
  const [sizeId, setSizeId] = useState("25x15");
  const [customW, setCustomW] = useState(25);
  const [customH, setCustomH] = useState(15);
  const [useCustom, setUseCustom] = useState(false);
  const [rows, setRows] = useState<Row[]>([
    { id: 1, amount: "99", qty: perSheetFor(25, 15) },
  ]);

  const size = useMemo(() => {
    if (useCustom) return makeSize(customW, customH);
    return SIZES.find((s) => s.id === sizeId)!;
  }, [useCustom, customW, customH, sizeId]);

  const updateRow = (id: number, patch: Partial<Row>) =>
    setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch } : r)));

  const labels = useMemo(() => {
    const out: { text: string; scale: number }[] = [];
    for (const r of rows) {
      const trimmed = r.amount.trim();
      const text = trimmed === "" ? "" : `${trimmed}/-`;
      const n = Math.max(0, Math.min(r.qty || 0, 2000));
      for (let i = 0; i < n; i++) out.push({ text, scale: scaleFor(trimmed) });
    }
    return out.slice(0, 4000);
  }, [rows]);


  return (
    <main className="min-h-screen bg-muted/40">
      <div className="no-print mx-auto max-w-3xl px-4 py-10">
        <h1 className="text-3xl font-bold tracking-tight">১৬ আনা Mart — Price Label Printer</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Enter a price, choose a label size and how many pieces you want, then print on
          yellow A4 label sheets.
        </p>

        <div className="mt-8 grid gap-6 rounded-xl border bg-card p-6 shadow-sm sm:grid-cols-2">
          <div className="sm:col-span-2">
            <p className="text-sm font-medium">Prices to print</p>
            <div className="mt-2 space-y-3">
              {rows.map((r) => (
                <div key={r.id} className="flex items-end gap-3">
                  <div className="flex-1">
                    <label className="text-xs text-muted-foreground">Amount (₹)</label>
                    <input
                      inputMode="decimal"
                      value={r.amount}
                      onChange={(e) => updateRow(r.id, { amount: e.target.value })}
                      className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-lg outline-none focus:ring-2 focus:ring-ring"
                      placeholder="99"
                    />
                  </div>
                  <div className="w-32">
                    <label className="text-xs text-muted-foreground">Pieces</label>
                    <input
                      type="number"
                      min={1}
                      max={2000}
                      value={r.qty}
                      onChange={(e) => updateRow(r.id, { qty: Number(e.target.value) })}
                      className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <button
                    type="button"
                    disabled={rows.length === 1}
                    onClick={() => setRows((rs) => rs.filter((x) => x.id !== r.id))}
                    className="rounded-md border px-3 py-2 text-sm disabled:opacity-40"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() =>
                setRows((rs) => [
                  ...rs,
                  { id: Math.max(0, ...rs.map((x) => x.id)) + 1, amount: "", qty: 10 },
                ])
              }
              className="mt-3 rounded-md border px-3 py-2 text-sm font-medium"
            >
              + Add another price
            </button>
            <p className="mt-2 text-xs text-muted-foreground">
              {labels.length} labels total · about {size.perSheet} fit on one A4 sheet.
            </p>
          </div>

          <div>
            <label className="text-sm font-medium" htmlFor="size">
              Label size
            </label>
            <select
              id="size"
              value={useCustom ? "custom" : sizeId}
              onChange={(e) => {
                if (e.target.value === "custom") setUseCustom(true);
                else {
                  setUseCustom(false);
                  setSizeId(e.target.value);
                }
              }}
              className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
            >
              {SIZES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label} · approx {s.perSheet} per A4
                </option>
              ))}
              <option value="custom">Custom size…</option>
            </select>
          </div>


          {useCustom && (
            <>
              <div>
                <label className="text-sm font-medium" htmlFor="cw">
                  Width (mm)
                </label>
                <input
                  id="cw"
                  type="number"
                  min={10}
                  max={200}
                  value={customW}
                  onChange={(e) => setCustomW(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2"
                />
              </div>
              <div>
                <label className="text-sm font-medium" htmlFor="ch">
                  Height (mm)
                </label>
                <input
                  id="ch"
                  type="number"
                  min={8}
                  max={200}
                  value={customH}
                  onChange={(e) => setCustomH(Number(e.target.value))}
                  className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2"
                />
              </div>
            </>
          )}

          <div className="sm:col-span-2">
            <button
              onClick={() => window.print()}
              className="w-full rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Print {labels.length} labels
            </button>
          </div>
        </div>

        <h2 className="mt-10 text-lg font-semibold">Preview</h2>
      </div>

      <div className="print-sheet mx-auto bg-white px-4 pb-16">
        <div className="flex flex-wrap content-start">
          {labels.map((l, i) => (
            <div
              key={i}
              className="label-cell relative overflow-hidden"
              style={{ width: `${size.w}mm`, height: `${size.h}mm` }}
            >
              <img
                src={LABEL_BASE_SRC}
                alt=""
                aria-hidden="true"
                className="absolute inset-0 h-full w-full object-fill"
              />
              <span
                className="absolute font-bold leading-none text-black"
                style={{
                  left: "36%",
                  top: "52%",
                  transform: "translateY(-50%)",
                  fontSize: `${size.h * l.scale}mm`,
                  whiteSpace: "nowrap",
                }}
              >
                {l.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
