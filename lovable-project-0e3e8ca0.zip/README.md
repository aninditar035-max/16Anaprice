# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Deploy to Cloudflare

```bash
bun install
bun run build      # outputs dist/server (worker) + dist/client (static assets)
npx wrangler deploy
```

The build uses the Nitro `cloudflare-module` preset. `wrangler.jsonc` in the project
root points Wrangler at that output. For Cloudflare's Git-connected "Workers" builds,
set the build command to `bun run build` and leave the deploy command as
`npx wrangler deploy`.
